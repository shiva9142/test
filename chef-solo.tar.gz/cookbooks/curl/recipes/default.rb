#
# Cookbook:: curl
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

package 'curl'
